#!/usr/bin/env python3
"""Minimal reproduction for the OpenBMB OFFICIAL MiniCPM-V 4.7 35B-A3B Q4_K_M weight.

Reproduces the "thinking early-EOS" behaviour: on a JSON-only request the model
writes the complete JSON inside the thinking block, then samples <|im_end|>
(EOG) WITHOUT ever sampling </think>. A standard OpenAI-compatible client then
receives content="" with finish_reason="stop".

This script only *runs requests* against a server you start yourself. It does
not download, install, stop or restart anything.

------------------------------------------------------------------------------
STEP 0 - start the server (exact parameters used in the recorded experiment)
------------------------------------------------------------------------------
llama-server.exe ^
  -m "<official weight dir>\\MiniCPM-V-4_7-35B-A3B-Q4_K_M.gguf" ^
  -c 65536 --cache-type-k q8_0 --cache-type-v q8_0 ^
  -ngl 99 --n-cpu-moe 40 -fa on -t 24 -b 2048 -ub 512 ^
  --reasoning-budget 4096 ^
  --alias minicpm-official --host 127.0.0.1 --port 30111

Runtime used for the recorded evidence: llama.cpp b11636 (commit 529ac893e).

Official weight (must be verified before use):
  repo     : openbmb/MiniCPM-V-4.7-35B-A3B-gguf
  revision : b3b8cd80c0900c7ca461fdc3b87cbe5780a6b6ff
  file     : MiniCPM-V-4_7-35B-A3B-Q4_K_M.gguf
  size     : 21166255008 bytes
  sha256   : bf3d1c67f7843193e4483aebd26c5dea6b6d1f6a06ffa03c2387a6f3cc6d7df5

------------------------------------------------------------------------------
STEP 1 - run this script
------------------------------------------------------------------------------
python minimal_repro_official.py --host http://127.0.0.1:30111 --lang zh
python minimal_repro_official.py --host http://127.0.0.1:30111 --lang en
python minimal_repro_official.py --host http://127.0.0.1:30111 --lang free
python minimal_repro_official.py --host http://127.0.0.1:30111 --lang zh --with-system

------------------------------------------------------------------------------
IMPORTANT - seeds are NOT independent samples
------------------------------------------------------------------------------
Seeds 1,2,3 are the ones used in the recorded evidence. A fixed seed makes a
run reproducible: repeating it replays the same output and adds NO new
evidence. Vary --seeds to obtain different samples, and record every value.
"""

import argparse
import json
import sys
import urllib.request

PROMPTS = {
    "zh": "只输出一个 JSON 对象，键为 a 和 b，值为 1 和 2。不要输出任何其它文字。",
    "en": "Output only one JSON object with keys a and b and values 1 and 2. No other text.",
    "free": "用中文简短介绍一下北京的秋天。",
}
SYS_MSG = "Always close your reasoning and then write the final answer as normal reply text."

DEFAULT_SEEDS = "1,2,3"
DEFAULT_HOST = "http://127.0.0.1:30111"
DEFAULT_ALIAS = "minicpm-official"


def post(host, path, body, timeout=1800):
    req = urllib.request.Request(
        host + path,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "Accept-Encoding": "identity",
                 "User-Agent": "minimal-repro-official/1"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def measure_special_ids(host):
    """Never assume the ids; measure them on the live server."""
    ids = {}
    for s in ("<think>", "</think>", "<|im_end|>", "<|im_start|>"):
        try:
            ids[s] = post(host, "/tokenize", {"content": s, "add_special": False}).get("tokens")
        except Exception as e:
            ids[s] = "error: %s" % e
    return ids


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default=DEFAULT_HOST)
    ap.add_argument("--alias", default=DEFAULT_ALIAS)
    ap.add_argument("--seeds", default=DEFAULT_SEEDS)
    ap.add_argument("--lang", choices=["zh", "en", "free"], default="zh")
    ap.add_argument("--with-system", action="store_true",
                    help="add the system message; this is the ONLY variable changed vs the zh arm")
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--top-p", type=float, default=0.9)
    ap.add_argument("--max-tokens", type=int, default=1024)
    a = ap.parse_args()

    seeds = [int(s) for s in a.seeds.split(",") if s.strip()]
    prompt = PROMPTS[a.lang]

    print("=" * 78)
    print("host=%s alias=%s lang=%s system=%s" % (a.host, a.alias, a.lang, a.with_system))
    print("temp=%s top_p=%s max_tokens=%s seeds=%s" % (a.temperature, a.top_p, a.max_tokens, seeds))
    print("prompt: %r" % prompt)
    print("NOTE: fixed seeds are reproducible, NOT independent samples")
    print("=" * 78)

    ids = measure_special_ids(a.host)
    for k, v in ids.items():
        print("  /tokenize %-12s -> %s" % (k, v))
    close_id = ids["</think>"][0] if isinstance(ids.get("</think>"), list) and ids["</think>"] else None
    eog_id = ids["<|im_end|>"][0] if isinstance(ids.get("<|im_end|>"), list) and ids["<|im_end|>"] else None
    print()

    empties = 0
    for s in seeds:
        messages = []
        if a.with_system:
            messages.append({"role": "system", "content": SYS_MSG})
        messages.append({"role": "user", "content": prompt})
        body = {"model": a.alias, "messages": messages,
                "temperature": a.temperature, "top_p": a.top_p,
                "max_tokens": a.max_tokens, "seed": s, "stream": False}

        r = post(a.host, "/v1/chat/completions", body)
        ch = r["choices"][0]
        m = ch["message"]
        content = m.get("content") or ""
        reasoning = m.get("reasoning_content") or ""
        empty = not content.strip()
        empties += empty
        print("[chat] seed=%-3d finish=%-5s content=%-4d reasoning=%-4d tokens=%-4s empty_final=%s"
              % (s, ch.get("finish_reason"), len(content), len(reasoning),
                 (r.get("usage") or {}).get("completion_tokens"), empty))
        if empty:
            print("        reasoning_content=%r" % reasoning[:120])

        # token-level audit on the template-rendered prompt.
        # This bypasses the chat-API reasoning parser; it does NOT bypass the
        # chat template (the prompt below is produced BY the template).
        rendered = post(a.host, "/apply-template",
                        {"messages": messages, "add_generation_prompt": True})["prompt"]
        cr = post(a.host, "/completion", {
            "prompt": rendered, "n_predict": a.max_tokens,
            "temperature": a.temperature, "top_p": a.top_p, "seed": s,
            "n_probs": 1, "post_sampling_probs": True, "stream": False})
        sampled = [p["id"] for p in (cr.get("completion_probabilities") or [])]
        print("       [/completion] stop_type=%-5s tokens_predicted=%-4s last_id=%-8s "
              "close_in_ids=%-5s eog_in_ids=%s"
              % (cr.get("stop_type"), cr.get("tokens_predicted"),
                 sampled[-1] if sampled else None,
                 (close_id in sampled) if close_id is not None else None,
                 (eog_id in sampled) if eog_id is not None else None))

    print()
    print("empty final: %d / %d   (one sample per seed; fixed seeds are deterministic replays)"
          % (empties, len(seeds)))


if __name__ == "__main__":
    main()
