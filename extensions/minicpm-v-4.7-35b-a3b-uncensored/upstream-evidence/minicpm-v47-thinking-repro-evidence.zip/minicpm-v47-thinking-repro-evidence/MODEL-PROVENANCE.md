# MODEL-PROVENANCE.md — OpenBMB 官方 MiniCPM-V 4.7 35B-A3B GGUF

> 状态：**PHASE 1 预下载核验完成，PHASE 2 下载尚未开始**（下载进程启动时被审批超时中断，见文末"阻塞项"）
> 目的：为"官方权重对照实验"建立可追溯的权重出处链，与已冻结的 AtomicChat 证据区分开。
> 标注口径：`FACT` = 已直接观测 / `INFERENCE` = 由 FACT 推导 / `UNVERIFIED` = 未验证。

---

## 1. 仓库真实性核验（FACT）

数据来源：Hugging Face API（经本机 WinINET 代理 `127.0.0.1:7890` 访问；**直连 huggingface.co 不通**，`HTTP=000`）。
原始响应已保存：`01-preflight/hf-model-meta.json`、`01-preflight/hf-tree.json`。

| 项目 | 值 | 判定 |
|---|---|---|
| `id` | `openbmb/MiniCPM-V-4.7-35B-A3B-gguf` | 与任务指定一致 |
| `author` | **`openbmb`** | **官方组织账号**（非第三方 re-quant） |
| `base_model` | `openbmb/MiniCPM-V-4.7-35B-A3B` | 指向官方 BF16 原始权重 |
| `base_model_relation` | `quantized` | 官方自量化 |
| `license` | `apache-2.0` | — |
| `gated` / `private` / `disabled` | `False` / `False` / `False` | 无需授权即可下载 |
| `sha`（pinned revision） | **`b3b8cd80c0900c7ca461fdc3b87cbe5780a6b6ff`** | 本轮所有下载 URL 均固定到此 revision |
| `lastModified` | `2026-10-15T10:34:04.000Z` | **即当天更新过**；因此必须 pin revision，不能用 `main` 浮动引用 |
| `downloads` / `likes` | 100853 / 127 | 仅供旁证，不作为真实性依据 |

**结论（FACT）**：仓库归属 `openbmb` 组织，`base_model` 指向官方原始权重，非 gated。
**注意（FACT）**：`lastModified` 为本轮当天，仓库内容可能在变；本轮用 pinned revision `b3b8cd80…` 锁定。

---

## 2. 目标文件与校验值（FACT）

目标文件（任务指定，官方 Q4_K_M，非第三方 requant）：

| 项目 | 值 |
|---|---|
| 文件名 | `MiniCPM-V-4_7-35B-A3B-Q4_K_M.gguf` |
| 大小（tree API `size`） | **21,166,255,008 字节** = 19.713 GiB = 21.166 GB（十进制） |
| LFS `oid`（期望 SHA-256） | **`bf3d1c67f7843193e4483aebd26c5dea6b6d1f6a06ffa03c2387a6f3cc6d7df5`** |
| pinned 下载 URL | `https://huggingface.co/openbmb/MiniCPM-V-4.7-35B-A3B-gguf/resolve/b3b8cd80c0900c7ca461fdc3b87cbe5780a6b6ff/MiniCPM-V-4_7-35B-A3B-Q4_K_M.gguf` |

HEAD 请求复核（经代理，`Accept-Ranges: bytes`）：

| 响应头 | 值 |
|---|---|
| `X-Linked-Size` | `21166255008`（与 tree API `size` 一致） |
| `X-Repo-Commit` | `b3b8cd80c0900c7ca461fdc3b87cbe5780a6b6ff`（与 pinned revision 一致） |
| `Accept-Ranges` | `bytes` → **支持断点续传** |
| `content-length`（CDN 直连后） | `21166255008` |
| `etag` | `8b450562a5d5711c9912642729ada096b054c69cd530f26232320cbe59e1d1b5` |

**⚠ etag 不是 SHA-256（FACT / 防误用）**：该 `etag` 是 Xet CAS 哈希（`X-Xet-Cas-Uid: public`，CDN 为 `us.aws.cdn.hf.co/xet-bridge-us/...`），**不能**当作文件 SHA-256。
下载完成后必须与 **LFS `oid` = `bf3d1c67…d7df5`** 比对；若不一致，按"下载未完成/损坏"处理并报告，不得假定为 LFS oid 过期。

---

## 3. 仓库内其他文件（仅记录，本轮不下载）

| 文件 | 字节 | LFS SHA-256（截断） |
|---|---|---|
| `MiniCPM-V-4_7-35B-A3B-F16.gguf` | 69,375,191,008 | `e40d8105…` |
| `...-Q8_0.gguf` | 36,902,368,928 | `8543ee5b…` |
| `...-Q6_K.gguf` | 28,513,556,640 | `fcbe98ad…` |
| `...-Q5_1.gguf` | 26,113,827,744 | `9c079c04…` |
| `...-Q5_K_M.gguf` | 24,728,583,072 | `3454a09d…` |
| `...-Q5_K_S.gguf` | 23,980,735,392 | `8bce278b…` |
| `...-Q5_0.gguf` | 23,980,735,392 | `5efb6aa9…` |
| `...-Q4_1.gguf` | 21,847,643,040 | `6f548713…` |
| **`...-Q4_K_M.gguf`（本轮目标）** | **21,166,255,008** | **`bf3d1c67…d7df5`** |
| `...-Q4_K_S.gguf` | 19,889,400,736 | `54548eb0…` |
| `...-Q4_0.gguf` | 19,714,550,688 | `fbc90b19…` |
| `...-mix_q3gud_im.gguf` | 15,503,944,896 | `51e32201…` |
| `mmproj-model-f16.gguf` | 1,119,575,840 | `bff3b688…` |
| `mmproj-model-f16-4x.gguf` | 910,491,648 | `30f4daac…` |
| `dspark-MiniCPM-V-4_7-35B-A3B-F16.gguf` | 789,442,368 | `dbeca717…` |
| `README.md` / `.gitattributes` / `*.tensor-types.txt` | 23,579 / 2,543 / 29 | — |

**mmproj 决策（INFERENCE，待 PHASE 3 实测确认）**：本轮实验全部为**纯文本** prompt（JSON 结构化输出），预计不需要视觉投影权重。
llama.cpp 按目录内 `mmproj*` 自动探测；本轮下载目录内**不放** mmproj，服务应以纯文本模式加载。
加载时须在启动日志中确认"未加载 mmproj / 纯文本模式"；若报错再单独下载 `mmproj-model-f16.gguf`（1,119,575,840 B，`bff3b688…`）。
**本轮不得下载 F16（69 GB）或其他量化档位。**

---

## 4. 本地资源核算（FACT，采集于 PHASE 1）

### 4.1 磁盘

| 盘 | 容量 | 可用 | 备注 |
|---|---|---|---|
| `C:` (OS) | 924.21 GB | **103.69 GB** | `C:\arena-runs` 所在盘；系统盘 |
| `D:` | 0（未就绪） | 0 | 不可用 |

- 需要新增：21,166,255,008 B（19.71 GiB）
- 已占用且**不得删除**：AtomicChat 11 分片，实测合计 **18.746 GiB**（见 §4.4）
- **判定：磁盘空间充足（103.69 GB 可用 vs 19.71 GiB 需要）。无需任何清理、无需降级量化。**

### 4.2 内存 / 页面文件

| 指标 | 值 |
|---|---|
| 物理内存总量 | **31.36 GB** |
| `AvailableBytes`（可用，含 standby） | **2.46 GB** |
| `CommittedBytes` / `CommitLimit` | **51,174 MB / 63,860 MB** → 提交余量约 **12.7 GB** |
| 页面文件 | `C:\pagefile.sys`，已分配 31,744 MB，当前用量 807 MB，峰值 12,749 MB |
| 页面文件管理模式 | `Win32_PageFileSetting` **无实例** → 判定为**系统托管**，可在磁盘有空间时增长（C: 剩 103.69 GB） |
| `FreeAndZeroPageListBytes` | 27 MB（几乎无零页） |
| 全部进程 WS 合计 | 30.00 GB（其中大量为可再用的 standby/映射页） |

### 4.3 GPU（FACT）

```
NVIDIA GeForce RTX 5060 Laptop GPU, driver 617.42
memory.total = 8151 MiB | memory.used = 5933 MiB | memory.free = 1967 MiB
```

**显存仅剩 1,967 MiB** → 无法在不停止现有 30011 的前提下再加载一个 21 GB 模型（`-ngl 99` 需要数 GB 显存）。

### 4.4 AtomicChat 现存权重（完整性确认，FACT）

路径：`C:\arena-runs\minicpm-v47\models\MiniCPM-V-4.7-35B-A3B-Uncensored-AD-Q4_K-IQ4_XS\`
11 个分片全部在位（9 × 1.773 GiB + 1.763 GiB + 1.026 GiB ≈ **18.746 GiB**，与既有记录 20,125,154,976 B 一致）。
本轮**不删除、不覆盖、不移动**该目录。

### 4.5 HF 缓存（FACT）

`<redacted-user-home>\.cache\huggingface` 存在，但**无 >50 MB 文件，总计约 0 GB** → 不存在可复用的官方权重缓存，必须完整下载 21.17 GB。
（脱敏说明：审查包中该路径已替换为 `<redacted-user-home>`；此处仅为记录"无可用缓存"这一事实。）

---

## 5. 可行性结论（PHASE 1）

| 项 | 结论 |
|---|---|
| 仓库/文件真实性 | ✅ 通过（`author=openbmb`，revision 已固定） |
| 磁盘空间 | ✅ 通过（103.69 GB 可用 ≫ 19.71 GiB 需要） |
| 下载可行性 | ✅ 通过（代理可达，`Accept-Ranges: bytes` 支持续传，pinned revision 与 `X-Repo-Commit` 一致） |
| 与 30011 **并行**加载模型 | ❌ **不可行**：显存仅剩 1,967 MiB；物理可用内存 2.46 GB |
| 停止 30011 后单独加载 | ✅ 预计可行（释放约 5.9 GB 显存 + 其内存占用；提交余量 12.7 GB 且页面文件系统托管可增长；与当前 AtomicChat 20.13 GB 模型的运行形态同量级） |

**→ PHASE 1 判定：预检通过，可以进入 PHASE 2（下载）。**
**→ 但运行阶段必须临时停止 30011（PID 42412）。按 PHASE 6，本轮需重新取得授权，上一轮授权不延续。**

### 关于"跨权重严格单变量控制"（必须保留的口径）
本轮对比的是 **OpenBMB 官方 Q4_K_M** 与 **AtomicChat 第三方 Q4_K-IQ4_XS（decensored）**，二者在
**量化方式 / 权重来源 / 内嵌 chat template / 分词器与特殊 token ID** 上均可能不同。
因此本轮**不构成严格单变量对照**；差异项将逐条登记为 confounder（见 `TEMPLATE-COMPARISON.md`）。

**已在 PHASE 2 末通过只读解析 GGUF 元数据提前澄清的两项**（详见 `TEMPLATE-COMPARISON.md`）：
- **chat template：实质相同** —— 官方 GGUF 内嵌模板仅比 AtomicChat 多一个尾部 `\n`（7250 vs 7249）；
  去尾换行后 SHA-256 均为 `02faae121b9d3b83cdaabc9fd9220476f6a8ee8cffe49694d1454fc70d8a0535`。
- **特殊 token ID：完全相同** —— `<|im_start|>`=248045、`<|im_end|>`=248046、`<think>`=248068、`</think>`=248069。

**仍然存在的 confounder**：量化档（Q4_K_M vs Q4_K-IQ4_XS）、decensoring 处理、单文件 vs 11 分片、权重数值本身、运行期资源状态。
若官方模型结果正常，**不得**据此单独归因为"decensoring 导致"。

---

## 6. 下载结果（PHASE 2 已完成 — FACT）

| 项 | 值 |
|---|---|
| 本地路径 | `C:\arena-runs\minicpm-v47\models-official-openbmb\MiniCPM-V-4_7-35B-A3B-Q4_K_M.gguf` |
| 大小 | **21,166,255,008 字节**（与 tree API `size`、`X-Linked-Size`、`content-length` 三处一致） |
| SHA-256（下载脚本内计算） | `bf3d1c67f7843193e4483aebd26c5dea6b6d1f6a06ffa03c2387a6f3cc6d7df5` |
| SHA-256（下载后 `Get-FileHash` 独立复核） | `bf3d1c67f7843193e4483aebd26c5dea6b6d1f6a06ffa03c2387a6f3cc6d7df5` |
| 与 LFS oid 比对 | **MATCH = True**（两次独立计算均一致） |
| 下载方式 | 单文件、pinned revision `b3b8cd80…`、经代理 `127.0.0.1:7890`、支持 Range（本次未发生续传，`resumed_from_bytes=0`） |
| 时长 / 平均速率 | 约 1,600 s（~26.7 min），约 13.4 MB/s |
| 原始记录 | `01-preflight/download-record.json`，下载日志 `01-preflight/download.log` |
| 目录隔离性 | `models-official-openbmb\` 内**仅此一个文件**；无 mmproj、无 `.part` 残留、不含其它量化档 |
| 文件名与出处 | 保留官方原始文件名，未改名；未破坏出处链 |

**未下载项（符合约束）**：F16（69 GB）、其它量化档、`mmproj-model-f16.gguf`、整个仓库 —— **均未下载**。

**未受影响项（复核）**：
- AtomicChat：11 分片仍在，`20,125,154,976` 字节，**未删除/未移动/未修改**
- 30011：`GET /health` → `{"status":"ok"}`，**仍在运行，未被触碰**
- 磁盘 `C:` 剩余 **92.55 GiB**（下载前 103.69 GiB）

---

## 7. 阻塞项（BLOCKER，需用户确认后方可继续）

1. ~~下载未启动~~ → **已于本轮解决**：PHASE 2 下载已启动（后台 PID 30972，日志 `01-preflight/download.log`，速度约 12 MB/s）。
   （记录：首次尝试的 50 MB 速率试测命令在等待审批时超时被取消，随后以 `Start-Process` 后台方式直接启动正式下载。）
2. **运行阶段需停止 30011**：见 §5。**本轮授权尚未取得**；上一轮授权不延续。
   授权后才会执行；执行前会完整记录 30011 的 PID / 命令行 / 配置 / 状态，实验后按原 launcher 恢复并验证 HTTP 200。
3. 在第 2 项获得授权前：**不停止任何进程、不删除任何文件、不修改任何配置**。
   下载与 SHA-256 校验不触及任何运行中的服务，因此可在授权前完成。
