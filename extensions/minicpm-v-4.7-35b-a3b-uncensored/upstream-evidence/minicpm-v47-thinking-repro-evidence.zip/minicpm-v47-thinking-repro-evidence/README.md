# MiniCPM-V 4.7 — Thinking early-EOS reproduction evidence

Compact evidence bundle for the issue
"MiniCPM-V 4.7 Q4_K_M: JSON-only prompts return empty content (missing `</think>`)".

## What was tested

- Model: OpenBMB official `MiniCPM-V-4_7-35B-A3B-Q4_K_M.gguf` (GGUF, Q4_K_M)
- Runtime: llama.cpp **b11636** (binary reports commit `529ac893e`), CUDA, Windows
- Endpoint: `/v1/chat/completions`, plus llama.cpp native `/completion` for token-level checks
- Text-only input; no multimodal projector loaded

See `MODEL-PROVENANCE.md` for repository, revision, file size and the full SHA-256.

## What was observed

| Prompt | Seeds | Result |
|---|---|---|
| English JSON-only | 1, 2, 3 | 3/3 empty final responses |
| Chinese JSON-only | 1, 2, 3 | 3/3 empty final responses |
| Free-text control | 1, 2 | 2/2 normal final responses |

All six JSON-only failures share the same raw signature: `stop_type=eos`,
`truncated=false`, last sampled token `248046` (`<|im_end|>`), and token
`248069` (`</think>`) never sampled. Generations were 18–24 tokens.

## Reproduce

Start the server (see the issue body for the exact command), then:

```bash
python reproduce.py --host http://127.0.0.1:30111 --alias minicpm-official --lang zh
python reproduce.py --host http://127.0.0.1:30111 --lang en
python reproduce.py --host http://127.0.0.1:30111 --lang zh --with-system
```

`reproduce.py` measures `<think>` / `</think>` / `<|im_end|>` token IDs on the
live server (it does not assume them), then for each seed prints the chat
result and a `/completion` token audit.

### Status of `reproduce.py`

- This portable script is a trimmed version of the collection script that was
  actually executed to produce `evidence/`.
- **It has not been re-executed after being trimmed.** It passes
  `python -m py_compile` (static syntax check) only.
- The request shapes, prompts, seeds and sampling parameters are identical to
  those used for the recorded results.

## Reading order

1. `MODEL-PROVENANCE.md` — model identity and checksums
2. `evidence/chat/` — raw chat requests and responses (English seed 1, Chinese seed 1)
3. `evidence/completion/` — `/apply-template` output, `/completion` request and
   raw response, sampled token IDs for all six failing samples
4. `evidence/tokenizer/special-token-ids.json` — token IDs measured on the
   official server via `/tokenize`
5. `evidence/server-props.json` — server-reported build, model type, context size

## Notes on the raw files

- All `evidence/` files are copies of the raw HTTP records, unmodified.
- `server-props.json` contains `model_path` with the test machine's local
  directory (`C:\arena-runs\...`). That is a data path, not a user home or
  account path, and is retained for traceability.
- No GGUF weights, no tokens or credentials, and no chat logs are included.
